app.controller('HomeController', function($scope) {
    $scope.message = "Welcome to LearnHub! Your learning journey starts here.";
  });
  
  app.controller('CoursesController', function($scope, CourseService) {
    // Fetch courses from service
    $scope.courses = CourseService.getCourses();
  });
  
  app.controller('CourseDetailController', function($scope, $routeParams, CourseService) {
    var courseId = $routeParams.id;
    $scope.course = CourseService.getCourseById(courseId);
  });
  

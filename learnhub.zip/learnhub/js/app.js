// Add AngularJS Routing
var app = angular.module('learningPortalApp', ['ngRoute']);

app.config(function ($routeProvider) {
  $routeProvider
    .when('/', {
      templateUrl: 'views/index.html',
      controller: 'HomeController'
    })
    .when('/courses', {
      templateUrl: 'views/courseslist.html',
      controller: 'CoursesController'
    })

    .when('/courses', {
      templateUrl: 'views/courses.html',
      controller: 'CoursesController'
    })


    .when('/course/:id', {
      templateUrl: 'views/course-detail.html',
      controller: 'CourseDetailController'
    })
    .otherwise({
      redirectTo: '/'
    });
});


// Home Controller
app.controller('HomeController', function ($scope) {
  $scope.message = "Welcome to LearnHub!";
});




// Login Controller
app.controller('LoginController', function ($scope) {
  $scope.user = {};
  $scope.message = '';
  $scope.messageClass = '';

  $scope.login = function (user) {
    if (user.username === 'test' && user.password === 'test123') {
      $scope.message = 'Login successful!';
      $scope.messageClass = 'alert-success';
    } else {
      $scope.message = 'Invalid credentials. Please try again.';
      $scope.messageClass = 'alert-danger';
    }
  };
});

// Signup Controller (if needed)
app.controller('SignupController', function ($scope) {
  $scope.user = {};

  $scope.signup = function () {
    if ($scope.user.password !== $scope.user.confirmPassword) {
      alert("Passwords do not match!");
      return;
    }
    alert("Signup successful for " + $scope.user.firstName + "!");
    $scope.user = {}; // Reset form fields
  };
});

